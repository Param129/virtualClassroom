/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import model.admin;
/**
 *
 * @author user
 */
public class fac extends admin{
    protected int Id;
    protected String name;
    protected String email;
    protected String mobileno;
    private  String password;
    protected String securityquestion;
    protected String secq_Ans;
    protected String status;
   
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    public String getmobileno() {
        return mobileno;
    }

    public void setmobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }

    public String getsecurityquestion() {
        return securityquestion;
    }

    public void setsecurityquestion(String securityquestion) {
        this.securityquestion = securityquestion;
    }

    public String getsecq_Ans() {
        return secq_Ans;
    }

    public void setsecq_Ans(String secq_Ans) {
        this.secq_Ans = secq_Ans;
    }

    public String getstatus() {
        return status;
    }

    public void setstatus(String status) {
        this.status = status;
    }
}
