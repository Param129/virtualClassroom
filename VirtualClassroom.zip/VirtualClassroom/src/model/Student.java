/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import model.admin;
/**
 *
 * @author user
 */      
public class Student extends admin{
    private int rollno;
    private String name;
    private String email;
    private String mobile;
    private String password;
    private String securityquestion;
    private String answer;
    private String status;

    public int getrollno() {
        return rollno;
    }

    public void setrollno(int rollno) {
        this.rollno = rollno;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    public String getmobilenumber() {
        return mobile;
    }

    public void setmobilenumber(String mobile) {
        this.mobile = mobile;
    }

    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }

    public String getsecurityquestion() {
        return securityquestion;
    }

    public void setsecurityquestion(String securityquestion) {
        this.securityquestion = securityquestion;
    }

    public String getanswer() {
        return answer;
    }

    public void setanswer(String answer) {
        this.answer = answer;
    }

    public String getstatus() {
        return status;
    }

    public void setstatus(String status) {
        this.status = status;
    }
    
}
