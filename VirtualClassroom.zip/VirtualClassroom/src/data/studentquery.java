/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import javax.swing.JOptionPane;
import model.Student;
import java.sql.*;
import java.util.*;
import model.fac;

/**
 *
 * @author user
 */
abstract class StudQuery {

    abstract void save();

}

public class studentquery extends StudQuery {

    public static void save(Student student) {
        String query = "insert into student(name,email,password,mobilenumber,securityquestion,answer,status)values('" + student.getname() + "','" + student.getemail() + "','" + student.getpassword() + "','" + student.getmobilenumber() + "','" + student.getsecurityquestion() + "','" + student.getanswer() + "','false')";
        DbOperations.setDataOrDelete(query, "Registered successfully, wait for admin approval.");
    }

    public static Student login(String email, String password) {
        Student student = null;
        try {
            ResultSet rs = DbOperations.getData("select * from student where email='" + email + "' and password='" + password + "'");
            while (rs.next()) {
                student = new Student();
                student.setstatus(rs.getString("status"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return student;
    }

    public static Student getsecurityquestion(String email) {
        Student student = null;
        try {
            ResultSet rs = DbOperations.getData("select * from student where email='" + email + "'");
            while (rs.next()) {
                student = new Student();
                student.setsecurityquestion(rs.getString("securityquestion"));
                student.setanswer(rs.getString("answer"));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return student;
    }

    public static void update(String email, String newpassword) {
        String query = "update student set password='" + newpassword + "' where email='" + email + "'";
        DbOperations.setDataOrDelete(query, "Password changed successfully.");
    }

    @Override
    void save() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static ArrayList<Student> getAllRecords(String email) {
        ArrayList<Student> arraylist = new ArrayList<>();
        try {
            ResultSet rs = DbOperations.getData("select * from student where email like'%" + email + "%'");
            while (rs.next()) {
                Student student = new Student();
                student.setrollno(rs.getInt("rollno"));
                student.setname(rs.getString("name"));
                student.setemail(rs.getString("email"));
                student.setpassword(rs.getString("password"));
                student.setmobilenumber(rs.getString("mobilenumber"));
                student.setstatus(rs.getString("status"));
                arraylist.add(student);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arraylist;
    }

    public static void changestatus(String email, String status) {
        String query = "update student set status='" + status + "' where email='" + email + "'";
        DbOperations.setDataOrDelete(query, "Status changed");
    }
}
