/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import javax.swing.JOptionPane;
import model.subjects;
import java.util.ArrayList;
import java.sql.*;
/**
 *
 * @author user
 */
public class category {
    public static void save(subjects sub){
        String query="insert into subjects(subject)values('"+sub.getSubject()+"')";
        DbOperations.setDataOrDelete(query,"Subject added successfully");
    }
    
    public static ArrayList<subjects> getAllRecords(){
        ArrayList<subjects> arrayList=new ArrayList<>();
        try{
            ResultSet rs=DbOperations.getData("select * from subjects");
            while(rs.next()){
                subjects sub=new subjects();
                sub.setId(rs.getInt("id"));
                sub.setSubject(rs.getString("subject"));
                arrayList.add(sub);
            }
        }
            catch(Exception e){
                    JOptionPane.showMessageDialog(null, e);
                    }
            return arrayList;
    }
    
    public static void delete(String id){
        String query="delete from subjects where id='"+id+"'";
        DbOperations.setDataOrDelete(query,"Subject deleted successfully");
    }
    
    
}
