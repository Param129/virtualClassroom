/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import javax.swing.JOptionPane;
import model.fac;
import java.sql.*;
import java.util.ArrayList;
import model.Student;
import model.admin;
//import data.DbOperations;
/**
 *
 * @author arjun
 */

public class query {
    public static void save(fac Faculty){
            String query = "insert into faculty( Name , Email, Password, Mobile_no,security_Question,Ans,Status)values('" + Faculty.getname() + "','" + Faculty.getemail() + "','" + Faculty.getpassword() + "','" + Faculty.getmobileno() + "','" + Faculty.getsecq_Ans() + "','" + Faculty.getsecq_Ans() + "','false')";
        operation.setDataOrDelete(query, "Registered successfully, wait for admin approval.");
            
    }
    public static admin login(String email, String password) {
        admin faculty = null;
        try {
            ResultSet rs = operation.getData("select * from faculty where Email='" + email + "' and password='" + password + "'");
            while (rs.next()) {
                faculty = new fac();
                faculty.setstatus(rs.getString("Status"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return faculty;
    }
     
    public static fac getsecurityquestion(String email) {
        fac faculty = null;
        try {
            ResultSet rs = operation.getData("select * from faculty where Email='" + email + "'");
            while (rs.next()) {
                faculty = new fac();
//                faculty.setSecurityquestion(rs.getString(" security_Question"));
//                faculty.setSecq_Ans(rs.getString("Ans"));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return faculty;
    }
    public static void updatesqurityquestion(String email,String sequestion,String answer){
        String query1 = "update faculty set security_Question='" + sequestion + "' where Email='" + email + "'";
        String query2 = "update faculty set Ans='" + answer + "' where Email='" + email + "'";
        operation.setDataOrDelete(query1, "Question changed successfully.");
        operation.setDataOrDelete(query2, "Answer changed successfully.");

    }
    public static void update(String email, String newpassword) {
        String query = "update faculty set password='" + newpassword + "' where Email='" + email + "'";
        operation.setDataOrDelete(query,"password changed");
    }
     public static void updatepassword(String email, String newpassword) {
        String query = "update faculty set password='" + newpassword + "' where Email='" + email + "'";
        operation.setDataOrDelete(query, "Password changed successfully.");
    }
    public static ArrayList<admin> getAllRecords(String email) {
        ArrayList<admin> arraylist = new ArrayList<>();
        try {
            ResultSet rs = DbOperations.getData("select * from faculty where email like'%" + email + "%'");
            while (rs.next()) {
                admin student = new fac();
                student.setId(rs.getInt("ID"));
                student.setname(rs.getString("name"));
                student.setemail(rs.getString("email"));
                student.setPassword(rs.getString("password"));
                student.setmobileno(rs.getString("Mobile_no"));
                student.setstatus(rs.getString("status"));
                arraylist.add(student);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arraylist;
    }
      public static void changestatus(String email, String status) {
        String query = "update faculty set status='" + status + "' where email='" + email + "'";
        DbOperations.setDataOrDelete(query, "Status changed");
    }
      
// bad me dekh lenge
     void save() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}