/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import model.newstudent;
import java.util.*;
import javax.swing.JOptionPane;
import java.sql.*;
import data.DbOperations;
/**
 *
 * @author user
 */
public class addnewstudent {
    public static void save(newstudent ns){
         String query = "insert into newstudent(id,name,subject)values('" + ns.getId()+ "','" + ns.getName() + "','" + ns.getSubject() +"')";
        DbOperations.setDataOrDelete(query, "Registered successfully.");
    }
    public static ArrayList<newstudent> getAllRecords(){
        ArrayList<newstudent> arraylist=new ArrayList<>();
        try{
            ResultSet rs=DbOperations.getData("select * from newstudent");
            while(rs.next()){
                newstudent ns=new newstudent();
                ns.setId(rs.getInt("id"));
                ns.setName(rs.getString("name"));
                ns.setSubject(rs.getString("subject"));
                arraylist.add(ns);
            }
        }
            catch(Exception e){
                    JOptionPane.showMessageDialog(null, e);
                    }
        return arraylist;
    }
    public static void update(newstudent ns){
        String query="update newstudent set subject='"+ns.getSubject()+"' where name='"+ns.getName()+"'";
        DbOperations.setDataOrDelete(query,"subject updated successfully");
    }
    public static void delete(String id,String subject){
        String query="delete from newstudent where id='"+id+"' and subject='"+subject+"'";
        DbOperations.setDataOrDelete(query," deleted successfully");
        
    }
}
