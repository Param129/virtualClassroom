/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class table {

    public static void main(String[] args) {
        try {
            String studenttable = "create table student(rollno int AUTO_INCREMENT primary key,name varchar(200),email varchar(200),password varchar(200),mobilenumber varchar(10),securityquestion varchar(200),answer varchar(200),status varchar(20),UNIQUE(email))";
            String admindetails = "insert into student(name,email,mobileNumber,password,securityQuestion,answer,status)values('Admin','admin@gmail.com','9760025358','admin','Who are you?','admin','true')";
            String subjectstable = "create table subjects(id int AUTO_INCREMENT primary key,subject varchar(200))";
            String newstudenttable = "create table newstudent(id  int(10) ,name varchar(200),subject varchar(200))";
            String factable="create table faculty(id int AUTO_INCREMENT primary key,Name varchar(30),Email varchar(50),Password varchar(20),Mobile_no varchar(10),security_Question varchar(50),Ans varchar(50),Status varchar(20))";
            String announcementtable="create table announcement(Topic varchar(100),Announcement varchar(500))";
            
            DbOperations.setDataOrDelete(studenttable, "Student table created successfully");
            DbOperations.setDataOrDelete(admindetails, "Admin details added successfully");
            DbOperations.setDataOrDelete(subjectstable, "subjects table created successfully");
            DbOperations.setDataOrDelete(newstudenttable, "newstudent table created successfully"); 
            DbOperations.setDataOrDelete(subjectstable, "subjects table created successfully");
            DbOperations.setDataOrDelete(announcementtable, "newstudent table created successfully");
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
